import pymysql
from gmssl import sm3,func,sm4,sm2
import secrets
import binascii

conn = pymysql.connect(
    host='127.0.0.1',
    port=3306,
    user='root',
    password='615911321',
    db='mmweb',
    )


def correct(username,password):
    sql = "SELECT salt,pw FROM user_info WHERE  users ='%s' "%(username)
    cur = conn.cursor()
    cur.execute(sql)
    result = cur.fetchall()
    
    if not result:  # 如果没有找到对应数据
        return False
        
    salted_password = result[0][0] + password
    hash_value =sm3.sm3_hash(func.bytes_to_list(salted_password.encode("utf-8")))
    if hash_value == result[0][1]:
        return True
    else:
        return False
    
def get_key(name,id,pw):
    public_key = 'cfb85a317c836c00bb7fc4f953c8b64814f9b6094d1716263de870a1b902c68ef27818d42d24e66691b2e91256a4eb9a10b69677b9ead114aef0b19c84843911'
    key1 = "a5f673f4c4cb2830878ddfa2d0eef6b5"
    cur = conn.cursor()
    sql = "SELECT key_A FROM message WHERE  recuser ='%s' AND downurl = '%s' "%(id,name)
    cur.execute(sql)
    key_A = cur.fetchall()[0][0]
    print("key_A = "+key_A)
    sql = "SELECT siyao FROM key_use WHERE  users ='%s' "%(id)
    cur = conn.cursor()
    cur.execute(sql)
    siyao_en = cur.fetchall()[0][0]
    siyao_de = decrypt_key(pw,siyao_en)
    print("private_key = " + siyao_de.decode())
    key = sm2_decrypt_key(bytearray.fromhex(key_A),siyao_de.decode())
    print("key = " + key.decode())
    return key.decode()
    
def sm2_encrypt_key(symmetric_key, public_key,private_key):
    sm2_crypt = sm2.CryptSM2(
        public_key=public_key,
        private_key=private_key  # 解密时不需要私钥
    )
    encrypted_key = sm2_crypt.encrypt(symmetric_key)
    return encrypted_key


def hash_login_password(password):
    """ 使用SM3对密码进行哈希处理，并截取前128位作为密钥 """
    hash_value = sm3.sm3_hash(func.bytes_to_list(password.encode()))
    return bytes.fromhex(hash_value[:32])  # 取前32个十六进制字符，即128位

def decrypt_key(password, encrypted_data):
    """ 基于口令生成密钥并解密数据 """
    key = hash_login_password(password)
    crypt_sm4 = sm4.CryptSM4()
    crypt_sm4.set_key(key, sm4.SM4_DECRYPT)
    encrypted_data = binascii.unhexlify(encrypted_data)
    decrypted_data = crypt_sm4.crypt_ecb(encrypted_data)

    return decrypted_data

def sm2_decrypt_key(encrypted_key, private_key):
    sm2_crypt = sm2.CryptSM2(
        public_key='',  # 加密时不需要公钥
        private_key=private_key
    )
    decrypted_key = sm2_crypt.decrypt(encrypted_key)
    
    return decrypted_key

def sm4_decrypt(file_path, key, pw):
    print(key)
    iv = generate_iv(pw).hex()
    if len(key) != 32:
        raise ValueError("Key must be 32 hex digits long (16 bytes).")
    if len(iv) != 32:
        raise ValueError("IV must be 32 hex digits long (16 bytes).")

    key_bytes = bytes.fromhex(key)
    iv_bytes = bytes.fromhex(iv)
    crypt_sm4 = sm4.CryptSM4()
    crypt_sm4.set_key(key_bytes, sm4.SM4_DECRYPT)

    with open(file_path, 'rb') as f:
        file_data = f.read()

    decrypted_data = crypt_sm4.crypt_cbc(iv_bytes, file_data)  # 使用CBC模式解密

    # 移除填充
    padding_length = decrypted_data[-1]
    decrypted_data = decrypted_data[:-padding_length]

    decrypted_file_path = file_path.split(".")[0]+'.'+file_path.split(".")[1]

    with open(decrypted_file_path, 'wb') as f:
        f.write(decrypted_data)

    return decrypted_file_path

def sm4_encrypt(file_path, key, pw):
    iv = generate_iv(pw).hex()
    if len(key) != 32:
        raise ValueError("Key must be 32 hex digits long (16 bytes).")
    if len(iv) != 32:
        raise ValueError("IV must be 32 hex digits long (16 bytes).")
    
    key_bytes = bytes.fromhex(key)
    iv_bytes = bytes.fromhex(iv)
    crypt_sm4 = sm4.CryptSM4()
    crypt_sm4.set_key(key_bytes, sm4.SM4_ENCRYPT)
    print(file_path)
    with open(file_path, 'rb') as f:
        file_data = f.read()

    # 填充数据以确保其长度是16的倍数
    padding_length = 16 - len(file_data) % 16
    file_data += bytes([padding_length] * padding_length)#采用的是PKCS#7填充标准

    encrypted_data = crypt_sm4.crypt_cbc(iv_bytes, file_data)  # 使用CBC模式加密
    encrypted_file_path = file_path + '.encrypted'

    with open(encrypted_file_path, 'wb') as f:
        f.write(encrypted_data)
        
# 使用示例：
def generate_iv(seed):
    # 使用 SM3 哈希种子
    hash_value = sm3.sm3_hash(func.bytes_to_list(seed.encode()))
    # 取哈希值的前32个十六进制字符（16字节）
    iv_hex = hash_value[:32]
    # 将十六进制字符串转换为字节
    iv_bytes = bytes.fromhex(iv_hex)
    return iv_bytes