from gmssl import sm3,func,sm4,sm2
import base64
import binascii
#16进制的公钥和私钥        


    
private_key = '00B9AB0B828FF68872F21A837FC303668428DEA11DCD1B24429D0C99E24EED83D5'
public_key = 'B9C9A6E04E9C91F7BA880429273747D7EF5DDEB0BB2FF6317EB00BEF331A83081A6994B8993F3F5D6EADDDB81872266C87C018FB4162F5AF347B483E24620207'
#数据和加密后数据为bytes类型
data = "111"
cryptSM2 = sm2.CryptSM2(private_key, public_key)
encrypted_password = cryptSM2.encrypt(data.encode())
print(encrypted_password.hex())
encrypted_password = '02e29158cb939b2281859dc100f55812db75dea80c458248247223064448c53f2433b3e26da02801dd402322ed77b707e464adaa59a8d9f41ca4d5beff738aa1ca71de7ab018eff592cbd7b1df518b11de1a3f7e32e44bc5a222aadd84bcc1e76bf739'
decrypted_password = cryptSM2.decrypt(bytearray.fromhex(encrypted_password))
print(decrypted_password.hex())



