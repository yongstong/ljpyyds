from PyQt5.QtWidgets import QMainWindow, QApplication, QMessageBox,QFileDialog
from Ui_untitled import Ui_MainWindow as window
import sys
from decode import correct,get_key,sm4_decrypt,sm4_encrypt

class win(QMainWindow,window):
    def __init__(self, parent=None):
        super(win,self).__init__(parent)
        self.setupUi(self)
        
    def Select_a_single_file(self):
        file_path, _ = QFileDialog.getOpenFileName(self, "选择文件", "", "All Files (*)")
        if file_path:
           id = self.lineEdit.text()
           pw = self.lineEdit_2.text()
           if correct(id,pw):
                file = file_path.split(r'/')[-1]
                file = "download\\\\"+file
                print(file)
                key = get_key(file,id,pw)
                sm4_decrypt(file_path,key,id)
                msg_box = QMessageBox(QMessageBox.Information, '消息', '解密完成')
                msg_box.exec_()
           else:
                msg_box = QMessageBox(QMessageBox.Warning, '错误', '账号或密码错误')
                msg_box.exec_()
if __name__ == '__main__':

    # id = '20211303'
    # pw = '615911321'
    # file_path =r'C:\Users\yyt\Documents\python_work\web\解密ui\街道划分图.pdf'
    # file_path2 = r'C:\Users\yyt\Documents\python_work\web\解密ui\街道划分图.pdf.encrypted'
    # # file = file_path.split(r'/')[-1]
    # # file = "download\\\\"+file
    # #   print(file)
    # # key = get_key(file,id,pw)
    # key = 'c7f3a92138f2cba92c10ad8711b18450'
    # # sm4_encrypt(file_path,key,pw)
    # sm4_decrypt(file_path2,key,id)


    app = QApplication(sys.argv)

    window = win()
    window.show()

    sys.exit(app.exec_())
 
 
 
 
# pw = 615911321   
# private_key = 038d7ed9dd0ebb9306daf0415250f19f112f6a5a86a8cdd4c88d6d15093b6586
# en_private_key = fe020870af6cc3390918bb00bb63110f5bf6b9b8d99352876f6b7fdccdb32c923687d0c05c7c8a73d127e92719e203c26e4abc46c12b3cd02093d78399beac6a0691858dec64ac4b709cb64d4665350d
# public_key = cfb85a317c836c00bb7fc4f953c8b64814f9b6094d1716263de870a1b902c68ef27818d42d24e66691b2e91256a4eb9a10b69677b9ead114aef0b19c84843911
# key = a5f673f4c4cb2830878ddfa2d0eef6b5
# key_a = 990055cb2efc56320a97502e2acdeac2d1f6f3e325deb7c006ee7ee6dd5a9581e7269d783fca318cdd15adb10b716a888b9b13a1b651df0c72c5c8eb0abebadcb7b1edae547f575d471b316d5184f74f6e710bae21e35ac0578cf7e9542fe4ab1a3051e02823723b7e6d1b9e70bd05f6d42441e076a0cd67706d9267158a6158