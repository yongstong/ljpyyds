package com.ruoyi.system.service.impl;

import java.util.List;
import com.ruoyi.common.utils.DateUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.ruoyi.system.mapper.CsDocumentMapper;
import com.ruoyi.system.domain.CsDocument;
import com.ruoyi.system.service.ICsDocumentService;
import com.ruoyi.common.core.text.Convert;

/**
 * 电子公文Service业务层处理
 * 
 * @author ruoyi
 * @date 2023-12-06
 */
@Service
public class CsDocumentServiceImpl implements ICsDocumentService 
{
    @Autowired
    private CsDocumentMapper csDocumentMapper;

    /**
     * 查询电子公文
     * 
     * @param id 电子公文主键
     * @return 电子公文
     */
    @Override
    public CsDocument selectCsDocumentById(Long id)
    {
        return csDocumentMapper.selectCsDocumentById(id);
    }

    /**
     * 查询电子公文列表
     * 
     * @param csDocument 电子公文
     * @return 电子公文
     */
    @Override
    public List<CsDocument> selectCsDocumentList(CsDocument csDocument)
    {
        return csDocumentMapper.selectCsDocumentList(csDocument);
    }

    /**
     * 新增电子公文
     * 
     * @param csDocument 电子公文
     * @return 结果
     */
    @Override
    public int insertCsDocument(CsDocument csDocument)
    {
        csDocument.setCreateTime(DateUtils.getNowDate());
        return csDocumentMapper.insertCsDocument(csDocument);
    }

    /**
     * 修改电子公文
     * 
     * @param csDocument 电子公文
     * @return 结果
     */
    @Override
    public int updateCsDocument(CsDocument csDocument)
    {
        csDocument.setUpdateTime(DateUtils.getNowDate());
        return csDocumentMapper.updateCsDocument(csDocument);
    }

    /**
     * 批量删除电子公文
     * 
     * @param ids 需要删除的电子公文主键
     * @return 结果
     */
    @Override
    public int deleteCsDocumentByIds(String ids)
    {
        return csDocumentMapper.deleteCsDocumentByIds(Convert.toStrArray(ids));
    }

    /**
     * 删除电子公文信息
     * 
     * @param id 电子公文主键
     * @return 结果
     */
    @Override
    public int deleteCsDocumentById(Long id)
    {
        return csDocumentMapper.deleteCsDocumentById(id);
    }
}
