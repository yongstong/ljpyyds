package com.ruoyi.system.mapper;

import java.util.List;
import com.ruoyi.system.domain.CsKeyManagement;

/**
 * 密钥管理Mapper接口
 * 
 * @author ruoyi
 * @date 2023-12-06
 */
public interface CsKeyManagementMapper 
{
    /**
     * 查询密钥管理
     * 
     * @param id 密钥管理主键
     * @return 密钥管理
     */
    public CsKeyManagement selectCsKeyManagementById(Long id);

    /**
     * 查询密钥管理列表
     * 
     * @param csKeyManagement 密钥管理
     * @return 密钥管理集合
     */
    public List<CsKeyManagement> selectCsKeyManagementList(CsKeyManagement csKeyManagement);

    /**
     * 新增密钥管理
     * 
     * @param csKeyManagement 密钥管理
     * @return 结果
     */
    public int insertCsKeyManagement(CsKeyManagement csKeyManagement);

    /**
     * 修改密钥管理
     * 
     * @param csKeyManagement 密钥管理
     * @return 结果
     */
    public int updateCsKeyManagement(CsKeyManagement csKeyManagement);

    /**
     * 删除密钥管理
     * 
     * @param id 密钥管理主键
     * @return 结果
     */
    public int deleteCsKeyManagementById(Long id);

    /**
     * 批量删除密钥管理
     * 
     * @param ids 需要删除的数据主键集合
     * @return 结果
     */
    public int deleteCsKeyManagementByIds(String[] ids);
}
