package com.ruoyi.system.service;

import java.util.List;
import com.ruoyi.system.domain.CsDocument;

/**
 * 电子公文Service接口
 * 
 * @author ruoyi
 * @date 2023-12-06
 */
public interface ICsDocumentService 
{
    /**
     * 查询电子公文
     * 
     * @param id 电子公文主键
     * @return 电子公文
     */
    public CsDocument selectCsDocumentById(Long id);

    /**
     * 查询电子公文列表
     * 
     * @param csDocument 电子公文
     * @return 电子公文集合
     */
    public List<CsDocument> selectCsDocumentList(CsDocument csDocument);

    /**
     * 新增电子公文
     * 
     * @param csDocument 电子公文
     * @return 结果
     */
    public int insertCsDocument(CsDocument csDocument);

    /**
     * 修改电子公文
     * 
     * @param csDocument 电子公文
     * @return 结果
     */
    public int updateCsDocument(CsDocument csDocument);

    /**
     * 批量删除电子公文
     * 
     * @param ids 需要删除的电子公文主键集合
     * @return 结果
     */
    public int deleteCsDocumentByIds(String ids);

    /**
     * 删除电子公文信息
     * 
     * @param id 电子公文主键
     * @return 结果
     */
    public int deleteCsDocumentById(Long id);
}
