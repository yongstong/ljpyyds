package com.ruoyi.system.service.impl;

import java.util.List;
import com.ruoyi.common.utils.DateUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.ruoyi.system.mapper.CsKeyManagementMapper;
import com.ruoyi.system.domain.CsKeyManagement;
import com.ruoyi.system.service.ICsKeyManagementService;
import com.ruoyi.common.core.text.Convert;

/**
 * 密钥管理Service业务层处理
 * 
 * @author ruoyi
 * @date 2023-12-06
 */
@Service
public class CsKeyManagementServiceImpl implements ICsKeyManagementService 
{
    @Autowired
    private CsKeyManagementMapper csKeyManagementMapper;

    /**
     * 查询密钥管理
     * 
     * @param id 密钥管理主键
     * @return 密钥管理
     */
    @Override
    public CsKeyManagement selectCsKeyManagementById(Long id)
    {
        return csKeyManagementMapper.selectCsKeyManagementById(id);
    }

    /**
     * 查询密钥管理列表
     * 
     * @param csKeyManagement 密钥管理
     * @return 密钥管理
     */
    @Override
    public List<CsKeyManagement> selectCsKeyManagementList(CsKeyManagement csKeyManagement)
    {
        return csKeyManagementMapper.selectCsKeyManagementList(csKeyManagement);
    }

    /**
     * 新增密钥管理
     * 
     * @param csKeyManagement 密钥管理
     * @return 结果
     */
    @Override
    public int insertCsKeyManagement(CsKeyManagement csKeyManagement)
    {
        csKeyManagement.setCreateTime(DateUtils.getNowDate());
        return csKeyManagementMapper.insertCsKeyManagement(csKeyManagement);
    }

    /**
     * 修改密钥管理
     * 
     * @param csKeyManagement 密钥管理
     * @return 结果
     */
    @Override
    public int updateCsKeyManagement(CsKeyManagement csKeyManagement)
    {
        csKeyManagement.setUpdateTime(DateUtils.getNowDate());
        return csKeyManagementMapper.updateCsKeyManagement(csKeyManagement);
    }

    /**
     * 批量删除密钥管理
     * 
     * @param ids 需要删除的密钥管理主键
     * @return 结果
     */
    @Override
    public int deleteCsKeyManagementByIds(String ids)
    {
        return csKeyManagementMapper.deleteCsKeyManagementByIds(Convert.toStrArray(ids));
    }

    /**
     * 删除密钥管理信息
     * 
     * @param id 密钥管理主键
     * @return 结果
     */
    @Override
    public int deleteCsKeyManagementById(Long id)
    {
        return csKeyManagementMapper.deleteCsKeyManagementById(id);
    }
}
