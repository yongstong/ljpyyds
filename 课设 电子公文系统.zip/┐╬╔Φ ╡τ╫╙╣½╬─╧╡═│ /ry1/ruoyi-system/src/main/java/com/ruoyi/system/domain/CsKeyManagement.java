package com.ruoyi.system.domain;

import org.apache.commons.lang3.builder.ToStringBuilder;
import org.apache.commons.lang3.builder.ToStringStyle;
import com.ruoyi.common.annotation.Excel;
import com.ruoyi.common.core.domain.BaseEntity;

/**
 * 密钥管理对象 cs_key_management
 * 
 * @author ruoyi
 * @date 2023-12-06
 */
public class CsKeyManagement extends BaseEntity
{
    private static final long serialVersionUID = 1L;

    /**  */
    private Long id;

    /** 密钥名称 */
    @Excel(name = "密钥名称")
    private String keyName;

    /** 密钥值 */
    @Excel(name = "密钥值")
    private String keyValue;

    public void setId(Long id) 
    {
        this.id = id;
    }

    public Long getId() 
    {
        return id;
    }
    public void setKeyName(String keyName) 
    {
        this.keyName = keyName;
    }

    public String getKeyName() 
    {
        return keyName;
    }
    public void setKeyValue(String keyValue) 
    {
        this.keyValue = keyValue;
    }

    public String getKeyValue() 
    {
        return keyValue;
    }

    @Override
    public String toString() {
        return new ToStringBuilder(this,ToStringStyle.MULTI_LINE_STYLE)
            .append("id", getId())
            .append("keyName", getKeyName())
            .append("keyValue", getKeyValue())
            .append("createTime", getCreateTime())
            .append("updateTime", getUpdateTime())
            .toString();
    }
}
