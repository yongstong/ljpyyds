package com.ruoyi.system.controller;

import java.util.List;
import org.apache.shiro.authz.annotation.RequiresPermissions;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import com.ruoyi.common.annotation.Log;
import com.ruoyi.common.enums.BusinessType;
import com.ruoyi.system.domain.CsKeyManagement;
import com.ruoyi.system.service.ICsKeyManagementService;
import com.ruoyi.common.core.controller.BaseController;
import com.ruoyi.common.core.domain.AjaxResult;
import com.ruoyi.common.utils.poi.ExcelUtil;
import com.ruoyi.common.core.page.TableDataInfo;

/**
 * 密钥管理Controller
 * 
 * @author ruoyi
 * @date 2023-12-06
 */
@Controller
@RequestMapping("/system/management")
public class CsKeyManagementController extends BaseController
{
    private String prefix = "system/management";

    @Autowired
    private ICsKeyManagementService csKeyManagementService;

    @RequiresPermissions("system:management:view")
    @GetMapping()
    public String management()
    {
        return prefix + "/management";
    }

    /**
     * 查询密钥管理列表
     */
    @RequiresPermissions("system:management:list")
    @PostMapping("/list")
    @ResponseBody
    public TableDataInfo list(CsKeyManagement csKeyManagement)
    {
        startPage();
        List<CsKeyManagement> list = csKeyManagementService.selectCsKeyManagementList(csKeyManagement);
        return getDataTable(list);
    }

    /**
     * 导出密钥管理列表
     */
    @RequiresPermissions("system:management:export")
    @Log(title = "密钥管理", businessType = BusinessType.EXPORT)
    @PostMapping("/export")
    @ResponseBody
    public AjaxResult export(CsKeyManagement csKeyManagement)
    {
        List<CsKeyManagement> list = csKeyManagementService.selectCsKeyManagementList(csKeyManagement);
        ExcelUtil<CsKeyManagement> util = new ExcelUtil<CsKeyManagement>(CsKeyManagement.class);
        return util.exportExcel(list, "密钥管理数据");
    }

    /**
     * 新增密钥管理
     */
    @GetMapping("/add")
    public String add()
    {
        return prefix + "/add";
    }

    /**
     * 新增保存密钥管理
     */
    @RequiresPermissions("system:management:add")
    @Log(title = "密钥管理", businessType = BusinessType.INSERT)
    @PostMapping("/add")
    @ResponseBody
    public AjaxResult addSave(CsKeyManagement csKeyManagement)
    {
        return toAjax(csKeyManagementService.insertCsKeyManagement(csKeyManagement));
    }

    /**
     * 修改密钥管理
     */
    @RequiresPermissions("system:management:edit")
    @GetMapping("/edit/{id}")
    public String edit(@PathVariable("id") Long id, ModelMap mmap)
    {
        CsKeyManagement csKeyManagement = csKeyManagementService.selectCsKeyManagementById(id);
        mmap.put("csKeyManagement", csKeyManagement);
        return prefix + "/edit";
    }

    /**
     * 修改保存密钥管理
     */
    @RequiresPermissions("system:management:edit")
    @Log(title = "密钥管理", businessType = BusinessType.UPDATE)
    @PostMapping("/edit")
    @ResponseBody
    public AjaxResult editSave(CsKeyManagement csKeyManagement)
    {
        return toAjax(csKeyManagementService.updateCsKeyManagement(csKeyManagement));
    }

    /**
     * 删除密钥管理
     */
    @RequiresPermissions("system:management:remove")
    @Log(title = "密钥管理", businessType = BusinessType.DELETE)
    @PostMapping( "/remove")
    @ResponseBody
    public AjaxResult remove(String ids)
    {
        return toAjax(csKeyManagementService.deleteCsKeyManagementByIds(ids));
    }
}
