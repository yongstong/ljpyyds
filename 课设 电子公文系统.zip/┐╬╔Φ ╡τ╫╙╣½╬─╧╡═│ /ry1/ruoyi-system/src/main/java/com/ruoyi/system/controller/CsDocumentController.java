package com.ruoyi.system.controller;

import java.util.List;
import org.apache.shiro.authz.annotation.RequiresPermissions;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import com.ruoyi.common.annotation.Log;
import com.ruoyi.common.enums.BusinessType;
import com.ruoyi.system.domain.CsDocument;
import com.ruoyi.system.service.ICsDocumentService;
import com.ruoyi.common.core.controller.BaseController;
import com.ruoyi.common.core.domain.AjaxResult;
import com.ruoyi.common.utils.poi.ExcelUtil;
import com.ruoyi.common.core.page.TableDataInfo;

/**
 * 电子公文Controller
 * 
 * @author ruoyi
 * @date 2023-12-06
 */
@Controller
@RequestMapping("/system/document")
public class CsDocumentController extends BaseController
{
    private String prefix = "system/document";

    @Autowired
    private ICsDocumentService csDocumentService;

    @RequiresPermissions("system:document:view")
    @GetMapping()
    public String document()
    {
        return prefix + "/document";
    }

    /**
     * 查询电子公文列表
     */
    @RequiresPermissions("system:document:list")
    @PostMapping("/list")
    @ResponseBody
    public TableDataInfo list(CsDocument csDocument)
    {
        startPage();
        List<CsDocument> list = csDocumentService.selectCsDocumentList(csDocument);
        return getDataTable(list);
    }

    /**
     * 导出电子公文列表
     */
    @RequiresPermissions("system:document:export")
    @Log(title = "电子公文", businessType = BusinessType.EXPORT)
    @PostMapping("/export")
    @ResponseBody
    public AjaxResult export(CsDocument csDocument)
    {
        List<CsDocument> list = csDocumentService.selectCsDocumentList(csDocument);
        ExcelUtil<CsDocument> util = new ExcelUtil<CsDocument>(CsDocument.class);
        return util.exportExcel(list, "电子公文数据");
    }

    /**
     * 新增电子公文
     */
    @GetMapping("/add")
    public String add()
    {
        return prefix + "/add";
    }

    /**
     * 新增保存电子公文
     */
    @RequiresPermissions("system:document:add")
    @Log(title = "电子公文", businessType = BusinessType.INSERT)
    @PostMapping("/add")
    @ResponseBody
    public AjaxResult addSave(CsDocument csDocument)
    {
        return toAjax(csDocumentService.insertCsDocument(csDocument));
    }

    /**
     * 修改电子公文
     */
    @RequiresPermissions("system:document:edit")
    @GetMapping("/edit/{id}")
    public String edit(@PathVariable("id") Long id, ModelMap mmap)
    {
        CsDocument csDocument = csDocumentService.selectCsDocumentById(id);
        mmap.put("csDocument", csDocument);
        return prefix + "/edit";
    }

    /**
     * 修改保存电子公文
     */
    @RequiresPermissions("system:document:edit")
    @Log(title = "电子公文", businessType = BusinessType.UPDATE)
    @PostMapping("/edit")
    @ResponseBody
    public AjaxResult editSave(CsDocument csDocument)
    {
        return toAjax(csDocumentService.updateCsDocument(csDocument));
    }

    /**
     * 删除电子公文
     */
    @RequiresPermissions("system:document:remove")
    @Log(title = "电子公文", businessType = BusinessType.DELETE)
    @PostMapping( "/remove")
    @ResponseBody
    public AjaxResult remove(String ids)
    {
        return toAjax(csDocumentService.deleteCsDocumentByIds(ids));
    }
}
